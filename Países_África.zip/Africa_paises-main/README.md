# Africa_paises
Trabalho de geografia sobre países da Africa cujo objetivo é criar um site inovador que faça com que os usuários aprendam mais sobre os países deste continente
