const board = document.getElementById("mapa")
var estaNoMapa = false

document.querySelectorAll(".allPaths").forEach(e => {
  e.addEventListener("mouseover", function () {
      var image = document.getElementById('flags');
      image.src = "bandeiras/"+e.id+".png"
      image.style.opacity = 1
      document.getElementById("name").style.opacity = 1
      document.getElementById("namep").innerText = e.id
       
      e.addEventListener("mouseleave", function () {
        document.getElementById("name").style.opacity = 0
        image.style.opacity = 0
      })
   })
})

board.addEventListener("mouseleave", () => {
  estaNoMapa = false
})

board.addEventListener("mouseover", () => {
  estaNoMapa = true
})

window.onmousemove = function (j) {
  x = j.clientX
  y = j.clientY
   
  if (estaNoMapa) {
    document.getElementById('name').style.top = window.scrollY + y-60  + 'px'
    document.getElementById('name').style.left = x+10 + 'px'
  }
  else {
    document.getElementById("name").style.opacity = 0
    document.getElementById('name').style.top = "-100%"
    document.getElementById('name').style.left = "0"
  }
}

const searchInput = document.getElementById('searchInput');
const itemList = document.getElementById('itemList');
const items = itemList.getElementsByTagName('li');

searchInput.addEventListener('input', () => {
  const searchQuery = searchInput.value.trim().toLowerCase();
  for (const item of items) {
    const itemText = item.innerText.toLowerCase();
    if (itemText.includes(searchQuery)) {
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  }
});

const barraSuperior = document.getElementsByClassName("barra-superior")[0]
const logoImagem = document.getElementsByClassName("logo-imagem")[0]
const logoTexto = document.getElementsByClassName("logo-texto")[0]
const subtitulo = document.getElementsByClassName("sub-titulo")[0]

function onResize() {
  var w = window.innerWidth
  var h = window.innerHeight

  const size = Math.min(h, w) * 0.9
  board.style.width = size + "px"
  board.style.height = size + "px"
  board.style.left = (w*0.5 - size/2) + "px"


  subtitulo.style.left = logoImagem.clientWidth+"px"
  logoTexto.style.left = logoImagem.clientWidth+"px"
  logoTexto.style.bottom = (subtitulo.clientHeight + barraSuperior.clientHeight*0.1)+"px"
}

onResize()
window.onresize = onResize